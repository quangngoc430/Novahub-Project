package vn.novahub.helpdesk.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.novahub.helpdesk.exception.DayOffTypeIsExistException;
import vn.novahub.helpdesk.exception.DayOffTypeIsNotValidException;
import vn.novahub.helpdesk.exception.DayOffTypeNotFoundException;
import vn.novahub.helpdesk.model.DayOffType;
import vn.novahub.helpdesk.service.DayOffTypeService;
import vn.novahub.helpdesk.service.LogService;
import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping(path = "/api", produces = {MediaType.APPLICATION_JSON_VALUE})
public class DayOffTypeController {

    private static final Logger logger = LoggerFactory.getLogger(DayOffTypeController.class);

    @Autowired
    private LogService logService;

    @Autowired
    private DayOffTypeService dayOffTypeService;

    @GetMapping(path = "/day-off-types/{account-id}")
    public ResponseEntity<Page<DayOffType>> getByAccountId(@PathVariable("account-id") long accountId,
                                                           Pageable pageable)
                                                                  throws DayOffTypeNotFoundException {

        Page<DayOffType> dayOffTypes = dayOffTypeService.findByAccountId(accountId, pageable);

        return new ResponseEntity<>(dayOffTypes, HttpStatus.OK);
    }

    @PostMapping(path = "/day-off-types")
    public ResponseEntity<String> create(@RequestBody DayOffType dayOffType)
            throws DayOffTypeIsExistException, DayOffTypeIsNotValidException {

        dayOffTypeService.add(dayOffType);

        return new ResponseEntity<>("Adding new Day off type successful", HttpStatus.OK);

    }

    @PutMapping(path = "/day-off-types")
    public ResponseEntity<String> update(@RequestBody DayOffType dayOffType,
                                                   HttpServletRequest request)
                                                   throws DayOffTypeNotFoundException {

        logService.log(request, logger);

        dayOffTypeService.update(dayOffType);

        return new ResponseEntity<>("Updating day off type successful", HttpStatus.OK);
    }

    @DeleteMapping(path = "/day-off-types/{type-id}")
    public ResponseEntity<String> delete(@PathVariable("type-id") long typeId) throws DayOffTypeNotFoundException {

        DayOffType dayOffType = dayOffTypeService.getById(typeId);

        dayOffTypeService.delete(dayOffType);

        return new ResponseEntity<>("Deleting day off type successful", HttpStatus.OK);
    }


}
