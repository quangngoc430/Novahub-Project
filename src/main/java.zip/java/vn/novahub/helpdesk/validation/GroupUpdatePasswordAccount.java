package vn.novahub.helpdesk.validation;

public interface GroupUpdatePasswordAccount {
}
