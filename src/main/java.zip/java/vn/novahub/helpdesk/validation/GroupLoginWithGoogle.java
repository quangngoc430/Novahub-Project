package vn.novahub.helpdesk.validation;

public interface GroupLoginWithGoogle {
}
