package vn.novahub.helpdesk.constant;

public class AccountConstant {

    public static final String STATUS_INACTIVE = "INACTIVE";
    public static final String STATUS_ACTIVE = "ACTIVE";
    public static final String STATUS_LOCKED = "LOCKED";

}
