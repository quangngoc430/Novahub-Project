package vn.novahub.helpdesk.constant;

public class IssueConstant {

    public static final String STATUS_APPROVE = "APPROVE";
    public static final String STATUS_DENY = "DENY";
    public static final String STATUS_PENDING = "PENDING";

}
