package vn.novahub.helpdesk.constant;

public class DayOffConstant {
    public static final String STATUS_APPROVE = "APPROVED";
    public static final String STATUS_DENY = "DENIED";
    public static final String STATUS_PENDING = "PENDING";
}
