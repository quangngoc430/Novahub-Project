package vn.novahub.helpdesk.constant;

public class RoleConstant {
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_CLERK = "CLERK";
    public static final String ROLE_USER = "USER";
    public static final String PREFIX_ROLE = "ROLE_";
}
