package vn.novahub.helpdesk.constant;

import vn.novahub.helpdesk.model.DayOffType;

public class DayOffTypeConstant {

    public static final String YEARLY_TYPE = "Nghi phep nam";

    public static final  String SICK_TYPE = "Nghi om";

    public static final  String PREGNANT_TYPE = "Nghi sinh";

    public static final  int QUOTA_OF_YEARLY= 15;

    public static final  int QUOTA_OF_SICK = 10;

    public static final  int QUOTA_OF_PREGNANT = 6;
}
